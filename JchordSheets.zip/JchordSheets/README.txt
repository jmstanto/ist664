**********************************
YUTOPIA's JEWISH GUITAR CHORDS

When I first started playing guitar, I noticed that there were few if any resources for Jewish players. Between Avi Chermon, friends, and me just figuring out stuff, I've collected the chords to quite a few popular Jewish songs - or at least the songs of which I know and/or can tolerate more than others. Initially I wanted to program a Jewish version of OLGA, but there really isn't a need for that just yet and I don't have the time.

These chords will only be a guideline for how to play certain songs. You'll have to listen to the original a few times to get the strumming patterns. With few if any exceptions, I used "basic" chords (sometimes with a capo) so you won't need to barre. If you want to transpose, add or remove a capo, or change any chords on your own, go right ahead. There is no "official" way to play any of these songs - do what's best for you.

Most of the Carlebach chords came from Avi Chermon's now defunct Carlebach website. I kept most of the songs as they are - honestly I don't know some of them - but I made changes to others.

Thanks to all who have helped contribute (far too many people to list). If you'd like to submit requests, new chord files, or correct mistakes, please use the comments section on the web page.

http://yutopia.yucs.org/chords/

*********************************